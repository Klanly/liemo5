﻿module("CommonShopUI", package.seeall)

    

local prefeb,grid,parentRoot,propCtr,btnBuy,BtnClose,BtnCost,BtnGift,BtnMat,Scrolliew;
local BtnUp,BtnUpDouble,BtnDown,BtnDownDouble;
local LabelCost,LabelGift,LabelMat;
-- local parentPosition = LuaHelper.LuaVector3(10,29,0);
-- local parentclipOffset = LuaHelper.LuaVector2(-140,-118);
local parentPosition = LuaHelper.LuaVector3(-172,-77,0);
local parentclipOffset = LuaHelper.LuaVector2(0,0);

local shopInfo = {};
local _sprites = {};
local TabIndex = 0;
local selectIndex = 0;
function Start()
	

end


function InitUI()

	prefeb = Resources.Load('Prefab/commonPrefab/ItemCommonShop');
	grid = GameObject.Find("Offset/Items/Grid"):GetComponent('UIGrid');
	parentRoot = GameObject.Find("Offset/Items");
	Scrolliew = parentRoot:GetComponent('UIScrollView');
	propCtr = GameObject.Find("Offset/curruntProp"):GetComponent('ItemCurruntPropCtr');

	BtnClose =  GameObject.Find("Offset/BtnClose");
	btnBuy = GameObject.Find("Offset/curruntProp/BtnBuy");

    BtnCost = GameObject.Find("Offset/btns/BtnCost");
    BtnGift = GameObject.Find("Offset/btns/BtnGift");
    BtnMat = GameObject.Find("Offset/btns/BtnMat");

    LabelCost = GameObject.Find("Offset/btns/BtnCost/lab");
    LabelGift = GameObject.Find("Offset/btns/BtnGift/lab");
    LabelMat = GameObject.Find("Offset/btns/BtnMat/lab");

    BtnUp = GameObject.Find("Offset/curruntProp/BtnUp");
    BtnUpDouble = GameObject.Find("Offset/curruntProp/BtnUpDouble");
    BtnDown = GameObject.Find("Offset/curruntProp/BtnDown");
    BtnDownDouble = GameObject.Find("Offset/curruntProp/BtnDownDouble");


    propCtr:clear();
	addEvent();
	setBtnStatus();
	BtnCost.transform:FindChild("bg").gameObject:SetActive(false);
    BtnCost.transform:FindChild("downBg").gameObject:SetActive(true);
    initposition();
    TabIndex = 0;

end



function initposition( ... )
	parentRoot.transform.localPosition = parentPosition;
    parentRoot:GetComponent('UIPanel').clipOffset = parentclipOffset;
end

function Item()

    Util.RemoveTableElement(_sprites);
	GameUtil.RemoveChildren(grid.gameObject.transform);
    shopInfo = ShopManager.GetInstance():getCommonShopInfo(TabIndex);

   
	local count = ShopManager.GetInstance().shopCount-1;
	for i=0,count do     
		ctr = CreateItem(grid.gameObject.transform);
		ctr.gameObject.name = i;
		-- ctr.transform.localPosition = Vector3(280*(i%2),-130*math.floor(i/2));
		ctr.transform.localPosition = Vector3(320*(i%2),-130*math.floor(i/2));
		script = ctr:GetComponent('ItemComShopCtr');
		script:setInfo(shopInfo[i]);
		script.Index = i;
        table.insert(_sprites,script);
	end
	propCtr:setInfo(shopInfo[selectIndex]);
    _sprites[selectIndex+1]:Setselect(true);

	--grid:Reposition();
	--Scrolliew:ResetPosition();
end
   

function CreateItem(parent)
	local go = GameObject.Instantiate(prefeb);
	GameUtil.SetParent(parent,go.transform);
	
	return go;
end

function addEvent()
	UIEventListener.Get(BtnClose).onClick = LuaHelper.VoidDelegate(BtnCloseOnClick);
	UIEventListener.Get(btnBuy).onClick = LuaHelper.VoidDelegate(BtnBuyOnClick);

	UIEventListener.Get(BtnCost).onClick = LuaHelper.VoidDelegate(BtnCostOnClick);
	UIEventListener.Get(BtnGift).onClick = LuaHelper.VoidDelegate(BtnGiftOnClick);
	UIEventListener.Get(BtnMat).onClick = LuaHelper.VoidDelegate(BtnMatOnClick); 

	UIEventListener.Get(BtnUp).onClick = LuaHelper.VoidDelegate(BtnUpOnClick);  
	UIEventListener.Get(BtnUpDouble).onClick = LuaHelper.VoidDelegate(BtnUpDoubleOnClick);  
	UIEventListener.Get(BtnDown).onClick = LuaHelper.VoidDelegate(BtnDownOnClick);  
	UIEventListener.Get(BtnDownDouble).onClick = LuaHelper.VoidDelegate(BtnDownDoubleOnClick);  

end

function OnItemClick( shop ,index)
	local count = Util.GetTableSize(_sprites);
    for i=1,count do     
		_sprites[i]:Setselect(false);
	end
		propCtr:setInfo(shop);
        propCtr:setIndex(shopInfo);
        selectIndex = propCtr.index;

end

function BtnUpOnClick( ... )
	propCtr:upEvent();
end

function BtnUpDoubleOnClick( ... )
	propCtr:upDoubleEvent();
end

function BtnDownOnClick( ... )
	propCtr:downEvent();
end

function BtnDownDoubleOnClick( ... )
	propCtr:downDoubleEvent();
end

function setBtnStatus( )
		BtnCost.transform:FindChild("bg").gameObject:SetActive(true);
        BtnCost.transform:FindChild("downBg").gameObject:SetActive(false);
        BtnGift.transform:FindChild("bg").gameObject:SetActive(true);
        BtnGift.transform:FindChild("downBg").gameObject:SetActive(false);
        BtnMat.transform:FindChild("bg").gameObject:SetActive(true);
        BtnMat.transform:FindChild("downBg").gameObject:SetActive(false);
end

function BtnCostOnClick( ... )
	if TabIndex==0 then return end;

	TabIndex = 0;
	selectIndex = 0;
	setBtnStatus();
	initposition();
	BtnCost.transform:FindChild("bg").gameObject:SetActive(false);
    BtnCost.transform:FindChild("downBg").gameObject:SetActive(true);
    Item();
end

function BtnGiftOnClick( ... )
	if TabIndex==2 then return end;

	TabIndex = 2;
	selectIndex = 0;
	setBtnStatus();
	initposition();
	-- LabelGift.color = ;
	-- LabelGift.color = color.grey;
	-- BtnGift.transform:FindChild("lab").gameObject.color = color.grey;
	-- BtnGift.gameObject.GetComponent<UILabel>.color = color.grey;
	-- BtnGift.transform.GetComponentInChildren<UISprite>().color = Color.grey;
	BtnGift.transform:FindChild("bg").gameObject:SetActive(false);
    BtnGift.transform:FindChild("downBg").gameObject:SetActive(true);
	Item();
end

function BtnMatOnClick( ... )
	if TabIndex==1 then return end;

	TabIndex = 1;
	selectIndex = 0;
	setBtnStatus();
	initposition();
	BtnMat.transform:FindChild("bg").gameObject:SetActive(false);
    BtnMat.transform:FindChild("downBg").gameObject:SetActive(true);
	Item();
end

function BtnCloseOnClick( ... )
	    ShopManager.comShopTabIndex = 0;
        ShopManager.comShopIndex = 0;
        PopupManager.getIns():CloseWindow(PopupManager.WindowIndex.COMMONSHOP);
end

function BtnBuyOnClick( ... )
	propCtr:OnShop();
end

function OnDisable( ... )
	
end