﻿module("Util", package.seeall)
--移除table中所有元素
function RemoveTableElement(t)
	local count = GetTableSize(t);
	for i=1,count do
		table.remove(t,1);
	end
end
--获取lable元素个数
function GetTableSize(t)
	local count = 0;
	for k,v in pairs(t) do
		count = count + 1;
	end
	return count;
end
function Require(name)
	LuaMain.Instance.mgr:DoFile(name);
end