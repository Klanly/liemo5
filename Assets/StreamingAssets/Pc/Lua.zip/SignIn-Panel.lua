module("SignIn-Panel", package.seeall)

local headLable,orderLable,tipsRppt,m_Scrolliew,tip,grid,ctr,m_Center,close_Btn,staySignInIndex,tips_lab,openVIP_Btn,Fill_check_Btn;
local ScrollUpPos = LuaHelper.LuaVector3(0,230,0);
local ScrollTopPos = LuaHelper.LuaVector3(0,-23,0);
local modelInfo = {};
local itemInfo = {};
local monthConfigData = {};
local modelData = {}; 
local serverData = {};
local tipCtrs = {};
function Start()
	InitUI();
	InitLogic();
end
function InitUI()
	modelInfo = ConfigManager.signIn;
	itemInfo = ConfigManager.items;
	tip = Resources.Load('Prefab/Tips/SignInTip');
	headLable = GameObject.Find('Offset/Sprite/Head-Sprite/Head-Label'):GetComponent('UILabel');
	orderLable = GameObject.Find('Offset/Sprite/Head-Sprite/Order-Label'):GetComponent('UILabel');
    openVIP_Btn=GameObject.Find('Offset/btnOpenVip');
    Fill_check_Btn=GameObject.Find('Offset/btnBuSign');
	tipsRoot = GameObject.Find('Offset/Scrollview-Panel/Grid');
	m_Scrolliew = GameObject.Find('Offset/Scrollview-Panel'):GetComponent('UIScrollView');
	close_Btn = GameObject.Find('Offset/Sprite/Close_Btn');
	UIEventListener.Get(close_Btn).onClick = LuaHelper.VoidDelegate(Close_Btn_OnClick);
	UIEventListener.Get(openVIP_Btn).onClick=LuaHelper.VoidDelegate(openVIP_Btn_OnClcik);
	UIEventListener.Get(Fill_check_Btn).onClick=LuaHelper.VoidDelegate(Fill_check_Btn_OnClick);
	if tipsRoot ~= nil then
		grid = tipsRoot:GetComponent('UIGrid');
		m_Center = tipsRoot:GetComponent('UICenterOnChild');
	end
end
function InitLogic()
	Util.RemoveTableElement(monthConfigData);
	local month = CurTimerManager.getIns():GetTimeNow().Month;
        NGUIUtil.SetLableText(headLable,string.format('%d月签到奖励',month));

	RefreshOrderLable();
	local days = DateTime.DaysInMonth(CurTimerManager.getIns():GetTimeNow().Year,month);
	for i=1,days do
		local key = month * 100 + i;
		if modelInfo[key] ~= nil then
			table.insert(monthConfigData,modelInfo[key]);
		end
	end
	AddItem();
	AddServerData();
	AddCofginInfo();
	GameCoroutine.instence:WaitFrame(Move);
end
function Move()
	if staySignInIndex > 17 then
		ScrollMove(ScrollUpPos);
	else
		ScrollMove(ScrollTopPos);
	end
end
function SignData_Event(sender,e)
	SetOrder(e.order);
end
function SetOrder(order)
	NGUIUtil.SetLableText(orderLable,string.format('本月已签到%d天',order));
end
function RefreshOrderLable()
	serverData = ServicePool.getIns():GetSignIn():GetSignServerData();
	SetOrder(serverData[0].SignInOrder);
end
function AddItem()
	local count = Util.GetTableSize(monthConfigData) - 1;
	for i=0,count do
		ctr = CreateItem(grid.gameObject.transform);
		ctr.gameObject.name = i;
		ctr:init();
	end
	grid:Reposition();
	m_Scrolliew:ResetPosition();
end
function AddServerData()
	local signLen = serverData[0].SignInInfo.Length;
	for i=1,signLen do
		if serverData[0].SignInInfo[i - 1] == 0 then
			--补签
			tipCtrs[i].state = SignInState.repair;
			print(tipCtrs[i]);
		elseif serverData[0].SignInInfo[i - 1] == 1 then
			--已签
			tipCtrs[i].state = SignInState.signIn;
		end
	end
	if serverData[0].SignInInfo[signLen - 1] == 0 then
		--待签
		tipCtrs[signLen].state = SignInState.staySignIn;
	else 
	    tipCtrs[signLen].state = SignInState.signIn;
	end
	staySignInIndex = signLen - 1;
end
function AddCofginInfo()
	local count = Util.GetTableSize(tipCtrs);
	for i=1,count do
		if monthConfigData ~= nil then
			local model = monthConfigData[i];
			tipCtrs[i]:SetRewardNum(model.rewardNum);
            tipCtrs[i]:SetDoubleShow(model.isOpenVIPDouble, model.multiples);
            if itemInfo[model.reward] ~= nil then
            	tipCtrs[i]:SetIcon(itemInfo[model.reward].item_icon);
            end
            tipCtrs[i].myId = model.id;
            local itemId = model.reward;
            if ConfigManager.items[itemId] ~= nil then
            	tipCtrs[i]:SetTipLable(ConfigManager.items[itemId].item_name, model.rewardNum);
            end
		end
	end
end
function CreateItem(parent)
	local go = GameObject.Instantiate(tip);
	GameUtil.SetParent(parent,go.transform);
	script = go:AddComponent('SignnInTipCtr');
	table.insert(tipCtrs,script);
	return script;
end
function ScrollMove(pos)
	SpringPanel.Begin(m_Scrolliew.panel.cachedGameObject,pos,8);
end
function Close_Btn_OnClick(obj)
	PopupManager.getIns():CloseWindow(PopupManager.WindowIndex.SIGNIN);
end
function openVIP_Btn_OnClcik(obj)
	PopupManager.getIns():PopWindow(PopupManager.WindowIndex.Vip,true,false);
end
function Fill_check_Btn_OnClick(obj)
	ctr:OnClickFillCheck();
end
function OnDisable()
	Util.RemoveTableElement(tipCtrs);
	staySignInIndex = nil;
end